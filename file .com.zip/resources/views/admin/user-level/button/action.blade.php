<a href="javascript:;" onclick="modal('edit', '#{{ $id }}', '{{ route('admin.' .request()->segment(2). '.edit', $id) }}')" class="badge badge-warning badge-sm" data-toggle="tooltip" data-placement="top" title="Edit">
    <i class="fa fa-edit fa-fw"></i>
</a>
