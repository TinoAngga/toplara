<?php

namespace App\Http\Controllers\Admin;

use App\Models\MutationBalance;
use Illuminate\Http\Request;

class MutationBalanceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\MutationBalance  $mutationBalance
     * @return \Illuminate\Http\Response
     */
    public function show(MutationBalance $mutationBalance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\MutationBalance  $mutationBalance
     * @return \Illuminate\Http\Response
     */
    public function edit(MutationBalance $mutationBalance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\MutationBalance  $mutationBalance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MutationBalance $mutationBalance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\MutationBalance  $mutationBalance
     * @return \Illuminate\Http\Response
     */
    public function destroy(MutationBalance $mutationBalance)
    {
        //
    }
}
