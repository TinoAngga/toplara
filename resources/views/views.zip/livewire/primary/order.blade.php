<style>
    .icon-service {
        bottom: 0%;
        right: 5%;
        position: absolute;
    }

</style>
<div class="position-relative">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="mb-3">
                    <div class="relative h-full">
                        <img class="banner-games blur-games lazy"
                            src="{{ asset(config('constants.options.asset_img_service_category') . $category->img) }}"
                            loading="lazy" alt="Top Up {{ $category->name }}" aria-label="Top Up {{ $category->name }}"
                        >
                        <div class="absolute inset-0 -z-10">
                            {{-- <div class="area">
                                <ul class="circles">
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                    <li></li>
                                </ul>
                            </div> --}}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div style="border-radius: 15px 15px 15px 15px;">

                <center>
                    <div class="card-img-top img-fluid single-product gradient-bg-card bg-single-game" style="
                                background-image: linear-gradient(to top, var(--tw-gradient-stops)), url('{{ asset(config('constants.options.asset_img_service_category') . $category->img) }}');
                                position: relative;">
                        <h6 class="card-title-game text-center">{{ $category->name }}</h6>
                    </div>
                </center>
                <div class="card" style="border: none; margin-top: -10px">
                </div>
                <div class="card shadow">
                    <div class="card-body">
                        {!! $category->description !!}
                    </div>
                </div>
                <div class="card shadow">
                    <div class="card-body">
                        <p class="text-white">Cara Order :</p>
                        {!! $category->information !!}
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <form method="POST" id="order-form">
                @csrf
                @method('POST')
                <input type="hidden" name="category" value="{{ $category->id }}" />
                <input type="hidden" name="is_check_id" value="{{ $category->is_check_id }}">
                <div class="row mt-2">
                    <div class="col-12 mb-2">

                        <div class="card shadow mt-2">
                            <div class="card-body">
                                <div style="border-bottom: 1px solid white;" class="mt-2 p-2">
                                    <h5>
                                        <span class="box-number">1</span>
                                        <p class="font ms-3">Masukan Data Tujuan</p>
                                    </h5>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6 col-12 mt-2">
                                        <input type="text" class="form-control shadow" name="data" id="data"
                                            placeholder="{{ $category->form_setting['placeholder_data'] ?? 'Masukan User ID' }}"
                                            style="border-radius: 10px;">
                                        <small class="text-danger data-invalid"></small>
                                    </div>
                                    @if ($category->is_additional_data == true)
                                    <div class="col-md-6 col-12 mt-2">
                                        @if (isset($category->form_setting['form_additional_data']) AND
                                        $category->form_setting['form_additional_data'] <> '')
                                            @php
                                            $getListServer = explode(',',
                                            $category->form_setting['form_additional_data']);
                                            @endphp
                                            <select class="form-control shadow" name="additional_data"
                                                id="additional_data" style="border-radius: 10px;"">
                                                    <option value=" 0" selected disabled>Pilih Salah Satu</option>
                                                @foreach ($getListServer as $server)
                                                @php $server = explode('|', $server) @endphp
                                                <option value="{{ $server[0] }}">{{ $server[1] }}</option>
                                                @endforeach
                                            </select>
                                            @else
                                            <input type="text" class="form-control shadow" name="additional_data"
                                                id="additional_data"
                                                placeholder="{{ $category->form_setting['placeholder_additional_data'] ?? 'Masukan Zone ID' }}"
                                                style="border-radius: 10px;">
                                            @endif
                                            <small class="text-danger additional_data-invalid"></small>
                                            <input type="hidden" name="additional_data_is_true" value="1">
                                    </div>
                                    @endif
                                </div>
                                @if (preg_match("/joki-mobile-legend/i", $category->slug))
                                <div class="row mt-2">
                                    <div class="col-md-6 col-12 mt-2">
                                        <label class="text-white">Tipe Login</label>
                                        <select class="form-control shadow" name="login" id="login"
                                            style="border-radius: 10px;">
                                            <option value="">Pilih tipe login</option>
                                            @foreach (config('constants.options.joki.mobile-legends.login') as $value)
                                            <option value="{{ $value }}">{{ $value }}</option>
                                            @endforeach
                                        </select>
                                        <small class="text-danger login-invalid"></small>
                                    </div>
                                    <div class="col-md-6 col-12 mt-2">
                                        <label class="text-white">Hero</label>
                                        <input type="text" class="form-control shadow" name="hero" id="hero"
                                            placeholder="Contoh: Hanzo, Fanny, Gusion, dll"
                                            style="border-radius: 10px;">
                                        <small class="text-danger hero-invalid"></small>
                                    </div>
                                    <div class="col-md-6 col-12 mt-2">
                                        <label class="text-white">Catatan untuk penjoki</label>
                                        <input type="text" class="form-control shadow" name="note" id="note"
                                            placeholder="Ketik catatan untuk penjoki" style="border-radius: 10px;">
                                        <small class="text-danger note-invalid"></small>
                                    </div>
                                    <div class="col-md-6 col-12 mt-2">
                                        <label class="text-white">User ID & Nickname</label>
                                        <input type="text" class="form-control shadow" name="user_nickname"
                                            id="user_nickname" placeholder="User Id & Nickname"
                                            style="border-radius: 10px;">
                                        <small class="text-danger user_nickname-invalid"></small>
                                    </div>
                                    <div class="col-md-12 col-12 mt-2">
                                        <label class="text-white">Whatsapp</label>
                                        <input type="text" class="form-control shadow" name="whatsapp" id="whatsapp"
                                            placeholder="Whatsapp" style="border-radius: 10px;">
                                        <small class="text-danger whatsapp-invalid"></small>
                                    </div>
                                </div>
                                @endif
                                <div class="mt-3">
                                    <button type="button" class="btn btn-primary btn-md font-weight-bold"
                                        data-bs-toggle="modal" data-bs-target="#exampleModal">Petunjuk</button>
                                </div>
                            </div>
                        </div>
                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    @if (!is_null($category->guide_img))
                                    <img src="{{ asset(config('constants.options.asset_img_service_category_guide') . $category->guide_img) }}"
                                        class="modal-content" style="width: 100%; height: auto;">
                                    @else
                                    -
                                    @endif
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-primary" data-dismiss="modal"><i
                                            class="fa fa-times"></i> TUTUP </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 mb-2">
                        <div class="card shadow">
                            <div class="card-body">
                                <div style="border-bottom: 1px solid white;" class="mt-2 p-2">
                                    <h5>
                                        <span class="box-number">2</span>
                                        <p class="font ms-3">Pilih Layanan</p>
                                    </h5>
                                </div>
                                <div class="mt-3">
                                    <div class="row">
                                        @forelse ($services as $key => $value)
                                        <div class="col-md-4 col-6">
                                            <input type="radio" id="service_{{ $value->id }}" class="radio-service"
                                                name="service" value="{{ $value->id }}">
                                            <label for="service_{{ $value->id }}" class="list-service">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <span>{{ ucwords(strtolower($value->name)) }}</span>
                                                        <br>

                                                    </div>
                                                    <div class="col">
                                                        <em class="em-price float-start mt-1">Rp
                                                            {{ currency(getServicePriceByLevel($value)) }}</em>
                                                        <img src="{{ get_icon($category->name, $value->name) }}"
                                                            width="32" class="float-end">
                                                    </div>
                                                </div>

                                            </label>
                                        </div>
                                        @empty
                                        <div class="col-md-12">

                                        </div>
                                        @endforelse
                                    </div>
                                    @if ($category->slug == 'joki-mobile-legends-ranked')
                                    <div class="row my-3">
                                        <div class="col-md-12 col-12 mt-2">
                                            <label class="text-white">Jumlah Bintang</label>
                                            <input type="text" class="form-control shadow" name="star" id="star"
                                                placeholder="star" style="border-radius: 10px;" value="1">
                                            <small class="text-danger star-invalid"></small>
                                        </div>
                                    </div>
                                    @endif
                                </div>
                                <small class="text-danger service-invalid"></small>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 mb-2">
                        <div class="card shadow">
                            <div class="card-body">
                                <div style="border-bottom: 1px solid white;" class="mt-2 p-2">
                                    <h5>
                                        <span class="box-number">3</span>
                                        <p class="font ms-3">Pilih Pembayaran</p>
                                    </h5>
                                </div>
                                <!-- <span class="strip-primary" style="margin-left: 54px"></span> -->
                                <style>
                                    input[type="radio"]:disabled+label {
                                        background: var(--theme-color-3);
                                    }

                                </style>
                                <div class="mt-3">
                                    @include('primary.product.payment-template')
                                </div>
                                <small class="text-danger payment-invalid"></small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 mb-5">
                    <div class="card shadow">
                        <div class="card-body">
                            <div style="border-bottom: 1px solid white;" class="mt-2 p-2">
                                <h5>
                                    <span class="box-number">4</span>
                                    <p class="font ms-3">Masukan Email</p>
                                </h5>
                            </div>
                            <div class="form-group mt-3">
                                <input type="text" name="email" id="email" class="form-control"
                                    placeholder="Email Aktif" aria-describedby="helpId" style="border-radius: 10px;">
                                <small class="text-danger email-invalid"></small>
                            </div>
                            <div class="form-group mt-3">
                                <button type="button" class="btn btn-md btn-primary shadow font-weight-bold"
                                    id="order-button"><i class="mdi mdi-cart"></i> Beli Sekarang</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal -->
                <div class="modal fade modal-order" id="modal-order" data-bs-backdrop="static" data-bs-keyboard="false"
                    tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title fw-bold" id="modal-order-title"></h5>
                            </div>
                            <div class="modal-body" id="modal-order-body">

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-md btn-secondary fw-bold"
                                    data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-md btn-primary fw-bold" id="modal-order-button"><i
                                        class="mdi mdi-cart"></i> Beli Sekarang</button>
                            </div>
                        </div>
                    </div>
                </div>

        </div>
        </form>
    </div>
</div>
