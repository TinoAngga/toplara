<div class="container">
    @foreach ($serviceCategoryType as $type)
    <div class="row mt-3" id="{{ $type->slug }}">
        <div class="col-12">
            <h5 class="text-shadow">{{ $type->slug == 'game' ? 'Top Up Game' : ucwords(str_replace('-', ' ', $type->name)) }}</h5>
            <span class="strip-primary"></span>
        </div>
    </div>
    <div class="row game mt-3">
        @foreach ($serviceCategory as $key => $value)
            @if ($value->service_type == $type->slug)
                <div class="col-sm-3 col-lg-2 col-4 text-center my-1" style="padding: 0px 6px; display: grid;">
                    <a href="{{ url('/product/' . $value->service_type . '/category/' . $value->slug) }}" class="text-decoration-none">
                        <div
                            class="card-custom img-hover-zoom rounded-4 overflow-hidden position-relative"

                        >
                            <img
                                src="{{ asset(config('constants.options.asset_img_service_category') . $value->img) }}"
                                data-src="{{ asset(config('constants.options.asset_img_service_category') . $value->img) }}"
                                loading="lazy"
                                class="card-img-custom w-100 h-100 object-fit-cover lazy"
                                height="100"
                                width="100"
                                alt="Top Up {{ $value->name }}"
                                srcset="{{ asset(config('constants.options.asset_img_service_category') . $value->img) }} 500w, {{ asset(config('constants.options.asset_img_service_category') . $value->img) }} 1000w, {{ asset(config('constants.options.asset_img_service_category') . $value->img) }} 1500w"
                            >

                            <span aria-hidden="true" class="absolute h-full gradient-bg-card"></span>
                            <h6 class="truncate card-title-game text-center">{{ $value->name }}</h6>

                        </div>

                    </a>
                    <div class="mt-4 d-none d-md-block"></div>
                </div>
            @endif
        @php
        flush();
        @endphp
        @endforeach
    </div>
    @endforeach
</div>
<style>
    .btn-topup {
        width: 80%;
        max-width: 100px;
    }

    .btn-topup:hover {
        color: #fff3e2 !important;
        width: 90%;
    }
    .col-hp {
        flex: 0 0 auto;
        width: 100%;
        font-size: 12px;
    }
    .size-img-product {
        width: 65%;
    }
    .rounded-img-product {
        border-radius: 0.5rem !important;
    }

</style>
<div class="pb-4">
    <div class="container">

    </div>
</div>
