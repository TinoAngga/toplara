<div>
    <div class="container">
        @include('primary.layouts.app.menu.nav')
        <div class="row">
            <div class="col-md-12 mb-3">
                <form method="GET" id="filter-form">
                    <div class="row">
                        <div class="form-group col-md-3">
                            <label>Filter Pembayaran</label>
                            <div class="input-group">
                                <select class="form-control" wire:model="filterPayment" id="filterPayment" wire:loading.attr="disabled" >
                                    <option value="" selected>Semua...</option>
                                    @foreach ($payments as $key => $value)
                                        <option value="{{ $value->id }}">{{ ucwords($value->name) }}</option>
                                    @endforeach
                                </select>
                                <button class="btn btn-primary" type="submit"><i class="fa fa-filter"></i></button>
                            </div>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Filter Status</label>
                            <div class="input-group">
                                <select class="form-control" wire:model="filterStatus" id="filterStatus" wire:loading.attr="disabled" >
                                    <option value="" selected>Semua...</option>
                                    @foreach ($status as $key => $value)
                                        <option value="{{ $value }}">{{ ucwords($value) }}</option>
                                    @endforeach
                                </select>
                                <button class="btn btn-primary" type="submit"><i class="fa fa-filter"></i></button>
                            </div>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Filter Lunas</label>
                            <div class="input-group">
                                <select class="form-control" wire:model="filterPaid" id="filterPaid"  wire:loading.attr="disabled" >
                                    <option value="" selected>Semua...</option>
                                    @foreach ($paid as $key => $value)
                                        <option value="{{ $key }}">{{ ucwords($value) }}</option>
                                    @endforeach
                                </select>
                                <button class="btn btn-primary" type="submit"><i class="fa fa-filter"></i></button>
                            </div>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Cari</label>
                            <div class="input-group">
                                <input type="text" class="form-control" wire:model="search" id="search" placeholder="Ketik sesuatu..." value="">
                                <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-12" style="margin-bottom: 20px; margin-top: -10px;">
            </div>
            <div class="col-lg-12">
                <div class="card m-b-30">
                    <div class="card-header bg-primary">
                        <h5 class="card-title-custom m-0 font-weight-bold text-white"><i class="mdi mdi-history"></i> Riwayat Deposit
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="display table table-striped table-bordered mb-0">
                                <thead>
                                    <tr>
                                        <th title="INVOICE" width="100px" class="text-white">INVOICE</th>
                                        <th title="WAKTU" width="100" class="text-white">WAKTU</th>
                                        <th title="PEMBAYARAN" width="40" class="text-white">PEMBAYARAN</th>
                                        <th title="NOMINAL" width="40" class="text-white">NOMINAL</th>
                                        <th title="SALDO" width="50" class="text-white">SALDO</th>
                                        <th title="LUNAS" class="text-center text-white" width="50">LUNAS</th>
                                        <th title="STATUS" class="text-center text-white" width="50">STATUS</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse ($deposits as $key => $value)
                                    <tr>
                                        <td title="INVOICE" width="100px" class="text-white">
                                            <a href="{{ route('deposit.invoice', $value->invoice) }}" class="btn btn-primary btn-md">
                                                <i class="mdi mdi-file-document-box-multiple-outline"></i>{{ $value->invoice }}
                                            </a>
                                        </td>
                                        <td title="WAKTU" width="100" class="text-white">{{ format_datetime($value->created_at) }}</td>
                                        <td title="PEMBAYARAN" width="40" class="text-white">{{ $value->payment->name }}</td>
                                        <td title="NOMINAL" width="40" class="text-white">{{ 'Rp ' . currency($value->amount) }}</td>
                                        <td title="SALDO" width="50" class="text-white">{{ 'Rp ' . currency($value->balance) }}</td>
                                        <td title="LUNAS" class="text-center text-white" width="50">{!! isPaid($value->is_paid) !!}</td>
                                        <td title="STATUS" class="text-center text-white" width="50">{!! badgeStatus($value->status, $value->is_paid) !!}</td>
                                    </tr>
                                    @empty
                                    <tr>
                                        <td colspan="7" class="text-white text-center">Tidak ada data</td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-3">
                            {{ is_array($deposits) === false ? $deposits->links() : '' }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
