@extends('admin.layouts.app')
@section('content')
<!-- Start row -->
<div class="row">
    <div class="col-lg-4 col-sm-6 col-12">
        <div class="card">
            <div class="card-header align-items-start pb-2">
                <div>
                    <h2 class="font-weight-bolder">{{ 'Rp ' . currency($widget['orders']['sum']) }}</h2>
                    <p class="card-text">{{ currency($widget['orders']['count']) }} Pesanan</p>
                </div>
                <div class="avatar bg-light-primary p-50">
                    <div class="avatar-content">
                        <i data-feather="shopping-cart" class="font-medium-5"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-sm-6 col-12">
        <div class="card">
            <div class="card-header align-items-start pb-2">
                <div>
                    <h2 class="font-weight-bolder">{{ 'Rp ' . currency($widget['deposits']['sum']) }}</h2>
                    <p class="card-text">{{ currency($widget['deposits']['count']) }} Deposit</p>
                </div>
                <div class="avatar bg-light-primary p-50">
                    <div class="avatar-content">
                        <i class="mdi mdi-credit-card-outline font-medium-5"> </i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-sm-6 col-12">
        <div class="card">
            <div class="card-header align-items-start pb-2">
                <div>
                    <h2 class="font-weight-bolder">{{ 'Rp ' . currency($widget['users']['sum']) }}</h2>
                    <p class="card-text">{{ currency($widget['users']['count']) }} Pengguna</p>
                </div>
                <div class="avatar bg-light-primary p-50">
                    <div class="avatar-content">
                        <i class="mdi mdi-account-multiple-outline font-medium-5"> </i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End row -->
@endsection
