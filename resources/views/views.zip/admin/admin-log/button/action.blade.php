<a href="javascript:;" onclick="modal('detail', '#{{ $id }}', '{{ route('admin.' .request()->segment(2). '.show', $id) }}')" class="badge badge-info badge-md" data-toggle="tooltip" data-placement="top" title="Detail">
    <i class="fa fa-search fa-fw"></i>
</a>
