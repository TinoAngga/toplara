@extends('primary.layouts.app')
@section('title')
{{ $page['title'] }}
@endsection
@section('style')
<style>

</style>
@endsection
@section('content')
<div class="position-relative">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-5">
                <div class="swiper" id="swiper-banner">
                    <div class="swiper-wrapper">
                        @if (count($banners) > 0)
                            @foreach ($banners as $key => $value)
                            <div class="swiper-slide">
                                <div class="card" style="cursor: pointer !important; border-radius: .25rem !important; border: none;">
                                    <div class="row g-0">
                                        <div class="col-md-12">
                                            <a href="{{ $value->url }}">
                                                <img
                                                    src="{{ asset(config('constants.options.asset_img_banner') . $value->value) }}"
                                                    class="d-block w-100 lazy img-fluid rounded-start"
                                                    data-src="{{ asset(config('constants.options.asset_img_banner') . $value->value) }}"
                                                    alt="{{ $value->name }}"
                                                    loading="lazy"
                                                    height="auto" width="auto"
                                                >
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        @else
                        @endif

                    </div>
                </div>
            </div>
        </div>

        <div class="absolute inset-0 -z-10">
            <div class="area">
                <ul class="circles">
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12 my-3">
            <h5 class="text-shadow">🔥 Populer</h5>
            <div class="tab-content pl-2 pr-2">
                <div class="row game">
                    @foreach ($populers as $key => $value)
                    <div class="col-sm-6 col-lg-4 col-6 text-center" style="display: grid;overflow: hidden;padding: 5px 5px;" onclick="window.location='{{ url('/product/' . $value->service_type . '/category/' . $value->slug) }}'">
                        <div class="game-populer-card" style="overflow: hidden;">
                            <div class="row">
                                <div class="col-4">
                                    <img
                                        class="game-img-populer lazy"
                                        src="{{ asset(config('constants.options.asset_img_service_category') . $value->img) }}"
                                        data-src="{{ asset(config('constants.options.asset_img_service_category') . $value->img) }}"
                                        loading="lazy"
                                        height="auto" width="auto"
                                        aria-label="Top Up {{ $value->name }}"
                                    />
                                </div>
                                <div class="col-8 text-end mt-4">
                                    <h6 class="card-title d-md-none" style="position: relative"> {{ $value->name }} </h6>
                                    <h6 class="card-title d-none d-md-block" style="position: relative"> {{ $value->name }} </h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-12 text-nowrap mb-2"
        style="border-bottom-left-radius: 0.5rem; border-bottom-right-radius: 0.5rem;">
        <div class="row">
            <div class="col-md-12 type-category-game my-2" style="overflow: auto;">
                <ul class="nav nav-pills d-inline-block py-1">
                    @foreach ($serviceCategoryType as $key => $value)
                    <li class="nav-item d-inline-block">
                        <a class="nav-link text-white @if($value->slug == 'top-up-game') nav-active @endif"
                            href="#{{ $value->slug }}"><small>{{ ucwords(str_replace('-', ' ', $value->name)) }}</small></a>
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
</div>
@livewire('primary.home', ['page' => $page['type'], 'serviceCategoryType' => $serviceCategoryType])
@endsection
@section('script')
<script>
    $('.nav-pills li a').on('click', function () {
        $('.nav-pills li').find('a.nav-active').removeClass('nav-active');
        $(this).addClass('nav-active');
    });
    const swiper1 = new Swiper('#swiper-banner', {
        effect: "coverflow",
        grabCursor: true,
        centeredSlides: true,
        slidesPerView: "auto",
        loop:true,
        speed: 2000,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        coverflowEffect: {
            rotate: 50,
            stretch: 0,
            // depth: 100,
            modifier: 1,
            slideShadows: true,
        },
        pagination: {
            el: ".swiper-pagination",
            dynamicBullets: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        }
    });

</script>
@endsection
