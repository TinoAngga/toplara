<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="description" content="{{ getConfig('meta_tags_description') }}">
    <meta name="keywords" content="{{ getConfig('meta_tags_keyword') }}">
    <meta name="author" content="DolananKode X Ahmad Andika">
    <meta property="og:locale" content="id_ID" />
    <meta property="og:type" content="website" />
    <meta name="og:site" content="{{ getConfig('title') }}">
    <meta property="og:title" content="{{ getConfig('title') }} - {{ $page['title'] }}" />
    <meta property="og:description" content="{{ getConfig('meta_tags_description') }}" />
    <meta property="og:site_name" content="{{ getConfig('title') }}" />
    <link rel="canonical" href="{{ url()->current() }}" />
    <link rel="alternate" hreflang="id-default" href="{{ config('app.url') }}" />
    <link rel="alternate" hreflang="en" href="{{ config('app.url') }}" />
    <meta property="og:image"
        content="{{ asset(config('constants.options.asset_img_website') . getConfig('meta_tags_image')) }}" />
    <meta property="og:url" content="{{ config('app.url') }}" />
    <meta property="og:image:secure_url"
        content="{{ asset(config('constants.options.asset_img_website') . getConfig('meta_tags_image')) }}" />
    <meta property="og:image:type" content="image/jpg, image/png, image/jpeg, image/ico, image/webp, image/svg" />
    <meta property="og:image:width" content="400" />
    <meta property="og:image:height" content="400" />

    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="{{ getConfig('title') }}">
    <meta name="twitter:site_name" content="{{ getConfig('title') }}">
    <meta name="twitter:title" content="{{ getConfig('title') }} - Top up Game Termurah dan Terpecaya">
    <meta name="twitter:description" content="{{ getConfig('meta_tags_description') }}">
    <meta name="twitter:image"
        content="{{ asset(config('constants.options.asset_img_website') . getConfig('meta_tags_image')) }}">
    <meta name="twitter:image:alt"
        content="{{ asset(config('constants.options.asset_img_website') . getConfig('meta_tags_image')) }}">

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title> @yield('title')</title>
    <!-- Fevicon -->
    <link rel="shortcut icon" href="{{ asset(config('constants.options.asset_img_website') . getConfig('favicon')) }}">
    <!-- Start CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" rel="preconnect" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet"rel="preconnect" href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/6.7.96/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="{{ asset('assets/plugins/simplebar/css/simplebar.css') }}">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="{{ asset('assets/css/animate.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/horizontal-menu.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/app-style.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/main.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/theme/app.min.css') }}">
    {{-- <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}"> --}}
    @yield('style')
    <style>
        table.dataTable thead th {
            color: #fff;
        }
        table.dataTable tbody td {
            color: #fff;
        }
        a.badge {
            text-decoration: none!important;
        }
    </style>
    @livewireStyles
    {!! getConfig('additional_head_scripts') !!}
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <div id="wrapper">
        <header>
            <nav class="navbar navbar-expand-lg fixed-top navbar-dark shadow-sm bg-custom">
                <div class="container">
                    <a class="navbar-brand" href="{{ url('/') }}">
                        <h4 class="">
                            @if (getConfig('logo'))
                            <img src="{{ asset(config('constants.options.asset_img_website') . getConfig('logo')) }}" alt="LOGO" style="height:33px;width:33px;" class="rounded">
                            @else
                            <i class="mdi mdi-gamepad"></i>
                            @endif
                            {{ getConfig('title') ?? 'TopUpGame' }}
                        </h4>
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse menu-utama justify-content-end" id="navbarSupportedContent">
                        <div class="navbar-nav ml-auto">
                            <a class="nav-item nav-link @if (request()->segment(1) == null || !in_array(request()->segment(1), ['service', 'account', 'auth', 'register', 'order']) ) active @endif" href="{{ url('/') }}">Home</a>
                            <a class="nav-item nav-link @if (request()->segment(2) == 'search') active @endif" href="{{ route('order.search.get') }}">Cari Pesanan</a>
                            <a class="nav-item nav-link @if (request()->segment(1) == 'service') active @endif" href="{{ route('service.index') }}">Daftar Harga</a>
                            @if (user() == false)
                            <a class="nav-item nav-link @if (request()->segment(2) == 'login') active @endif" href="{{ route('auth.login.get') }}"> Login </a>
                            <a class="nav-item nav-link @if (request()->segment(2) == 'register') active @endif" href="{{ route('auth.register.get') }}"> Register </a>
                            @endif
                            @if (user())
                            <a class="nav-item nav-link @if (request()->segment(1) == 'account') active @endif" href="{{ url('account') }}"> Dashboard </a>
                            @endif
                        </div>
                    </div>
                </div>
            </nav>
        </header>

        <div class="content py-5">
            @include('alert')
            @yield('content')
        </div>

        <footer id="aboutus" class="bg-footer">
            <div class="custom-shape-divider-top-1686901712">
                <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
                    <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" class="shape-fill"></path>
                </svg>
            </div>
            <div style="background: var(--theme-color-2);margin-top: -4px;">
                <div class="pt-5 pb-5">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4 mb-5">
                                @if (getConfig('logo'))
                                    <h5 class="pb-2">
                                        <img src="{{ asset(config('constants.options.asset_img_website') . getConfig('logo')) }}" alt="{{ getConfig('bartitle') }}" style="height:33px;width:33px;" class="rounded"> {{ getConfig('title') }}
                                    </h5>
                                @else
                                    <h5 class="pb-2">
                                        <i class="mdi mdi-gamepad"></i> {{ getConfig('title') }}
                                    </h5>
                                @endif

                                <span class="strip-primary mb-2"></span>
                                <p class="mt-4 text-white">{{ getConfig('meta_tags_description') ?? '-' }}</p>
                            </div>
                            <div class="col-md-4 mb-5">
                                <h5 class="pb-2">Produk Terpopuler</h5>
                                <span class="strip-primary mb-2"></span>
                                <div class="row mt-4" id="getPopularCategory">
                                </div>
                            </div>
                            <div class="col-md-4 mb-5">
                                <h5 class="pb-2">Hubungi Kami</h5>
                                <span class="strip-primary mb-2"></span>
                                <div class="mt-4">
                                    <a href="https://instagram.com/{{ getConfig('social_media_instagram') }}" target="_blank" role="link"
                                        style="font-size: 20px; text-decoration: none;">
                                        <i class="mdi mdi-instagram mr-4"></i><font size="2"> {{ getConfig('social_media_instagram') }} </font>
                                    </a>
                                    <br>
                                    <a href="https://wa.me/{{ getConfig('social_media_whatsapp') }}" target="_blank" role="link"  style="font-size: 20px; text-decoration: none;">
                                        <i class="mdi mdi-whatsapp mr-4"></i><font size="2"> {{ getConfig('social_media_whatsapp') }} </font>
                                    </a>
                                    <br>
                                    <a href="https://facebook.com/{{ getConfig('social_media_facebook_url') }}" target="_blank" role="link"
                                        style="font-size: 20px; text-decoration: none;">
                                        <i class="mdi mdi-facebook mr-4"></i><font size="2"> {{ getConfig('social_media_facebook_name') }} </font>
                                    </a><br>
                                    <a href="mailto:{{ getConfig('contact_email_address') }}" target="_blank" role="link"
                                        style="font-size: 20px; text-decoration: none;">
                                        <i class="mdi mdi-email mr-4"></i><font size="2"> {{ getConfig('contact_email_address') }} </font>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 mb-5">
                                <h5 class="pb-2">Halaman</h5>
                                <span class="strip-primary mb-2"></span>
                                <ul class="menu-list mt-4">
                                    @foreach (getSiteMap() as $key => $value)
                                        <li>
                                            <a href="{{ url('page/sitemap/' . $value->slug) }}">{{ ucfirst(strtolower($value->title)) }}</a>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                            <div class="col-md-4 mb-5">
                                <h5 class="pb-2">Metode Pembayaran</h5>
                                <span class="strip-primary mb-2"></span>
                                <div class="mt-4">
                                <marquee>
                                  <img src="{{ url('cdn/payment-method/list/') }}/bca_footer.png" alt="BCA" width="80px" class="ml-3 bg-white p-1">
                                  <img src="{{ url('cdn/payment-method/list/') }}/linkaja_footer.png" alt="LINK AJA" width="80px" class="ml-3 bg-white p-1">
                                  <img src="{{ url('cdn/payment-method/list/') }}/shopay_footer.png" alt="SHOPEEPAY" width="80px" class="ml-3 bg-white p-1">
                                  <img src="{{ url('cdn/payment-method/list/') }}/ovo_footer.png" alt="OVO" width="80px" class="ml-3 bg-white p-1">
                                  <img src="{{ url('cdn/payment-method/list/') }}/gopay_footer.png" alt="GOPAY" width="80px" class="ml-3 bg-white p-1">
                                  <img src="{{ url('cdn/payment-method/list/') }}/dana_footer.png" alt="DANA" width="80px" class="ml-3 bg-white p-1">
                                  <img src="{{ url('cdn/payment-method/list/') }}/qris_footer.png" alt="QRIS" width="80px" class="ml-3 bg-white p-1">
                                  <img src="{{ url('cdn/payment-method/list/') }}/indomaret_footer.png" alt="INDOMARET" width="80px" class="ml-3 bg-white p-1">
                              </marquee>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-theme1 text-center pb-4 pt-4">
                {{ !is_null(getConfig('footer_description')) ? convertString(getConfig('footer_description')) : '© '.date('Y').' '.getConfig('title').' - All Rights Reserved.' }}
            </div>
        </footer>
    </div>
    <div href="#" class="act-btn-top back-to-top" onclick="toTop()" style="display: none;">
            <i class="fa fa-angle-double-up"></i>
        </div>
    </div>
    <div class="fab-container">
        <div class="fab fab-icon-holder" style="background-color:#FFF; padding:5px">
            <img src="{{ asset('assets/img/call-center.png') }}" class="img-fluid" alt="Call Center {{ getConfig('title') }}">
        </div>
        <ul class="fab-options">
            <li>
                <a href="https://wa.me/{{ getConfig('social_media_whatsapp') }}" class="text-decoration-none" target="_blank" role="link" aria-labelledby="Whatsapp {{ getConfig('title') }}" aria-label="Whatsapp {{ getConfig('title') }}">
                    <div class="fab-icon-holder" style="background-color: #25D366;">
                        <i class="fab fa-whatsapp"></i>
                    </div>
                </a>
            </li>
            <li>
                <a href="https://instagram.com/{{ getConfig('social_media_instagram') }}" class="text-decoration-none" target="_blank" role="link" aria-labelledby="{{ getConfig('title') }}" aria-label="Instagram {{ getConfig('title') }}">
                    <div class="fab-icon-holder" style="background: radial-gradient(circle farthest-corner at 35% 90%, #fec564, transparent 50%), radial-gradient(circle farthest-corner at 0 140%, #fec564, transparent 50%), radial-gradient(ellipse farthest-corner at 0 -25%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 20% -50%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 0, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 60% -20%, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 100%, #d9317a, transparent), linear-gradient(#6559ca, #bc318f 30%, #e33f5f 50%, #f77638 70%, #fec66d 100%);">
                        <i class="fab fa-instagram"></i>
                    </div>
                </a>
            </li>
            <li>
                <a href="https://facebook.com/{{ getConfig('social_media_facebook_url') }}" class="text-decoration-none" target="_blank" role="link" aria-labelledby="Facebook {{ getConfig('title') }}" aria-label="Facebook {{ getConfig('title') }}">
                    <div class="fab-icon-holder" style="background-color: #0F92F3;">
                        <i class="fab fa-facebook-f"></i>
                    </div>
                </a>
            </li>
            <li>
                <a href="mailto:{{ getConfig('contact_email_address') }}" class="text-decoration-none" target="_blank" role="link" aria-labelledby="Email Address {{ getConfig('title') }}" aria-label="Email Address {{ getConfig('title') }}">
                    <div class="fab-icon-holder" style="background-color: #2FA6DE;">
                        <i class="fa fa-envelope"></i>
                    </div>
                </a>
            </li>
                    <!-- <li>
                <a href="https://tiktok.com/" class="text-decoration-none" target="_blank">
                    <div class="fab-icon-holder" style="background-color: #000000;">
                        <i class="fab fa-tiktok"></i>
                    </div>
                </a>
            </li> -->
        </ul>
        <a href="#" class="act-btn-top text-decoration-none" onclick="toTop()" style="display: none; background-color: #bd4cae; bottom: 19px;">
            <i class="fas fa-angle-up mt-2"></i>
        </a>
    </div>
    <!--<a href="https://api.whatsapp.com/send?phone={{ getConfig('social_media_whatsapp') }}">
        <img src="https://hantamo.com/free/whatsapp.svg" class="whatsapp-button" alt="Whatsapp-Button"/>
    </a> -->
    <style>
        .whatsapp-button{
            width:50px;
            height:50px;
            position:fixed;
            bottom:20px;
            right:20px;
            z-index:100;
        }
    </style>
    <!--End wrapper-->
    <!-- Bootstrap core JavaScript-->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
    <!--Select Plugins Js-->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <!--Data Tables js-->
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vanilla-lazyload@17.7.0/dist/lazyload.min.js"></script>
    <script src="{{ asset('js/main.custom.js') }}"></script>
    @livewireScripts
        <script>
        mybutton = document.querySelector(".act-btn-top");
        window.onscroll = function() {
            scrollFunc();
        };

        function scrollFunc() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                mybutton.style.display = "block";
            } else {
                mybutton.style.display = "none";
            }
        }

        function toTop() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }


    </script>
    <script>
        getPopularCategory();
        async function getPopularCategory(){
            fetch('{{ url('/') }}?type=getPopularCategory').then(function (response) {
                return response.text();
            }).then(function (html) {
                document.getElementById('getPopularCategory').innerHTML = html;
            }).catch(function (err) {
                console.warn('Something went wrong.', err);
            });
        }
    </script>
    <script>
        let img = document.querySelectorAll(".lazy");
        new LazyLoad(img);

    </script>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

    </script>
    <script>
        let Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });

        function logout() {
            swal.fire({
                title: "Apakah anda yakin?",
                html: '<b style="font-weight: bold;">Akan logout</b>?',
                icon: "warning",
                showCancelButton: !0,
                confirmButtonText: "Ya, Logout!",
                cancelButtonText: "Tidak, Batalkan!",
                confirmButtonClass: "btn btn-success",
                cancelButtonClass: "btn btn-danger",
            }).then(result => {
                if (result.value) {
                    window.location = '{{ route('logout') }}';
                } else {
                    swal.fire("Dibatalkan", "Logout di batalkan.", "error");
                }
            });
        }

    </script>
    @yield('script')
    @stack('script')
    <div class="modal fade" id="modal-form" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true"
        style="display: none;">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h6 class="modal-title" id="modal-title"></h6>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <div class="modal-body" id="modal-detail-body">...</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    {!! getConfig('additional_body_scripts') !!}

</body>

</html>
